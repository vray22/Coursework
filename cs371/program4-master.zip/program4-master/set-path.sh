export CLASSPATH=.:/home/vray/JUNIT_HOME/junit-4.12.jar:/home/vray/JUNIT_HOME/hamcrest-core-1.3.jar
